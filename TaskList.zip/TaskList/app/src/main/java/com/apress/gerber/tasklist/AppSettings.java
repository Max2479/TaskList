package com.apress.gerber.tasklist;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RelativeLayout;

public class AppSettings extends AppCompatActivity {

    Button buttonblue, buttonred, buttongreen, buttongrey, buttonyellow;
    RelativeLayout layout;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_app_settings);

        buttonred = findViewById(R.id.Buttonred);
        buttonblue = findViewById(R.id.Buttonblue);
        buttongreen = findViewById(R.id.Buttongreen);
        buttongrey = findViewById(R.id.Buttongrey);
        buttonyellow = findViewById(R.id.Buttonyellow);
        layout = findViewById(R.id.relativelayout);


        buttonred.setOnClickListener(new View.OnClickListener(){
        @Override
            public void onClick(View v) {
           // SharedPreferences sp = getSharedPreferences("MySharedPrefs", Context.MODE_PRIVATE);
            layout.setBackgroundColor(Color.RED);
            //SharedPreferences.Editor editor = sp.edit();
            //editor.putInt("layout", Color.RED);
            //editor.commit();
        }
        });
        buttonblue.setOnClickListener(new View.OnClickListener(){
                @Override
                public void onClick(View v) {
                    layout.setBackgroundColor(Color.BLUE);
                }
        });

        buttongreen.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                layout.setBackgroundColor(Color.GREEN);
            }
        });

        buttongrey.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                layout.setBackgroundColor(Color.WHITE);
            }
        });

        buttonyellow.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                layout.setBackgroundColor(Color.YELLOW);
            }
        });





    };

    public void openHome (View view) {
        Intent back_home = new Intent(this, Homepage.class);
        startActivity(back_home);

    }

}