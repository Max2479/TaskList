package com.apress.gerber.tasklist;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;

import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.Toast;

public class Homepage extends AppCompatActivity  {
    //RelativeLayout layout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_homepage);


    }
    //@Override
    //protected void onResume() {
        //super.onResume();
        //layout = findViewById(R.id.relativelayout);
        //SharedPreferences AppSettings = getSharedPreferences("MySharedPrefs", Context.MODE_PRIVATE);
        //if (AppSettings.getInt("layout", Color.WHITE) == Color.RED)
            //layout.setBackgroundColor(Color.RED);
        //else
            //layout.setBackgroundColor(Color.WHITE);
    //}
    public void openWorkTasks (View view) {
        Intent work_tasks = new Intent (this, WorkTasks.class);
        startActivity(work_tasks);
    }

    public void openPersonalTasks (View view) {
        Intent personal_tasks = new Intent (this, PersonalTasks.class);
        startActivity(personal_tasks);

    }

    public void openEducationalTasks (View view) {
        Intent educational_tasks = new Intent (this, EducationalTasks.class);
        startActivity(educational_tasks);
    }

    public void openAppSettings (View view) {
        Intent app_settings = new Intent (this, AppSettings.class);
        startActivity(app_settings);
    }

}